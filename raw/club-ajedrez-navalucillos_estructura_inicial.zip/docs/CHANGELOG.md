# Registro de Cambios

## [0.1.0] - Pre-Alpha
- Estructura inicial creada.
