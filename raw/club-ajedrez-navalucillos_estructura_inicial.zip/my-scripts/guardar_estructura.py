# Script para guardar estructura del proyecto (pendiente de implementación)
